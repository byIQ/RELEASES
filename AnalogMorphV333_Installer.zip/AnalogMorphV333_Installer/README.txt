━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📦 AnalogMorphV333 Plugin Installer v1.0.0
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

INSTALLATION INSTRUCTIONS:
━━━━━━━━━━━━━━━━━━━━━━━━━
1. Double-click "Install.command"
2. If prompted, enter your password
3. Wait for installation to complete
4. Restart your DAW
5. Rescan plugins

INSTALLATION PATHS:
━━━━━━━━━━━━━━━━━━━
EOF

    if [ "true" = "true" ]; then
        echo "• VST3: ~/Library/Audio/Plug-Ins/VST3/AnalogMorphV333.vst3" >> "/Users/indraqadarsih/Downloads/AnalogMorphV333_Installer/README.txt"
    fi
    if [ "true" = "true" ]; then
        echo "• AU:   ~/Library/Audio/Plug-Ins/Components/AnalogMorphV333.component" >> "/Users/indraqadarsih/Downloads/AnalogMorphV333_Installer/README.txt"
    fi
    if [ "0" -gt 0 ]; then
        echo "• Presets (0): ~/Library/Audio/Presets/AnalogMorphV333/" >> "/Users/indraqadarsih/Downloads/AnalogMorphV333_Installer/README.txt"
    fi

    cat >> "/Users/indraqadarsih/Downloads/AnalogMorphV333_Installer/README.txt" << README_EOF

TROUBLESHOOTING:
━━━━━━━━━━━━━━━━
• Plugin not showing in DAW? Restart DAW and rescan plugins.
• "Unidentified developer" warning? Right-click → Open → Open.
• Installation failed? Check Terminal for error messages.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Created: 2026-02-03 07:23:26
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
