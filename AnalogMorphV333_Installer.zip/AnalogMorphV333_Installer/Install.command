#!/bin/bash
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# AnalogMorphV333 Plugin Installer v1.0.0
# Double-click this file to install
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
VST3_ZIP="${SCRIPT_DIR}/vst3.zip"
AU_ZIP="${SCRIPT_DIR}/au.zip"
PRESETS_ZIP="${SCRIPT_DIR}/presets.zip"

VST3_TARGET="$HOME/Library/Audio/Plug-Ins/VST3"
AU_TARGET="$HOME/Library/Audio/Plug-Ins/Components"
PRESET_TARGET="$HOME/Library/Audio/Presets/AnalogMorphV333"

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m'

print_success() { echo -e "${GREEN}✅ $1${NC}"; }
print_warning() { echo -e "${YELLOW}⚠️  $1${NC}"; }
print_error() { echo -e "${RED}❌ $1${NC}"; }
print_info() { echo -e "${BLUE}ℹ️  $1${NC}"; }
print_header() { echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"; }

clear

print_header
echo -e "${BOLD}${CYAN}📦 AnalogMorphV333 Plugin Installer${NC}"
echo -e "${CYAN}   Version 1.0.0${NC}"
print_header
echo ""

TEMP_DIR=$(mktemp -d)
trap "rm -rf '$TEMP_DIR'" EXIT

HAS_VST3=true
HAS_AU=true
HAS_PRESETS=false

print_info "Archive status:"
if [ "$HAS_VST3" = "true" ] && [ -f "$VST3_ZIP" ]; then
    echo "  ✅ VST3: Available"
else
    echo "  ❌ VST3: Not available"
fi
if [ "$HAS_AU" = "true" ] && [ -f "$AU_ZIP" ]; then
    echo "  ✅ AU: Available"
else
    echo "  ❌ AU: Not available"
fi
if [ "$HAS_PRESETS" = "true" ] && [ -f "$PRESETS_ZIP" ]; then
    echo "  ✅ Presets: Available"
else
    echo "  ❌ Presets: Not available"
fi
echo ""

if [ "$HAS_VST3" = "false" ] && [ "$HAS_AU" = "false" ] && [ "$HAS_PRESETS" = "false" ]; then
    print_error "No archives found!"
    exit 1
fi

print_info "Installation targets:"
if [ "$HAS_VST3" = "true" ]; then
    echo "  📁 VST3: $VST3_TARGET/AnalogMorphV333.vst3"
fi
if [ "$HAS_AU" = "true" ]; then
    echo "  📁 AU:   $AU_TARGET/AnalogMorphV333.component"
fi
if [ "$HAS_PRESETS" = "true" ]; then
    echo "  📁 Presets: $PRESET_TARGET"
fi
echo ""

echo -e "${YELLOW}Continue with installation? (y/n)${NC}"
read -p "> " -n 1 -r
echo ""

if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    print_info "Installation cancelled."
    exit 0
fi

echo ""
print_header
print_info "Installing..."
print_header
echo ""

INSTALL_SUCCESS=true

if [ "$HAS_VST3" = "true" ] && [ -f "$VST3_ZIP" ]; then
    print_info "Installing VST3..."

    if ! mkdir -p "$VST3_TARGET" 2>/dev/null; then
        print_error "Failed to create directory: $VST3_TARGET"
        INSTALL_SUCCESS=false
    else
        if unzip -o -q "$VST3_ZIP" -d "$VST3_TARGET" 2>/dev/null; then
            print_success "VST3 extracted to: $VST3_TARGET"

            # CRITICAL: Fix dylib path references for DAW compatibility
            # Patches absolute paths to use @loader_path for bundled dependencies
            VST3_BINARY="$VST3_TARGET/AnalogMorphV333.vst3/Contents/MacOS/AnalogMorphV333"
            if [ -f "$VST3_BINARY" ]; then
                install_name_tool -change "/tmp/openssl-universal/lib/libssl.3.dylib" "@loader_path/../Frameworks/libssl.dylib" "$VST3_BINARY" 2>/dev/null || true
                install_name_tool -change "/tmp/openssl-universal/lib/libcrypto.3.dylib" "@loader_path/../Frameworks/libcrypto.dylib" "$VST3_BINARY" 2>/dev/null || true
                install_name_tool -change "/opt/homebrew/lib/libssl.3.dylib" "@loader_path/../Frameworks/libssl.dylib" "$VST3_BINARY" 2>/dev/null || true
                install_name_tool -change "/opt/homebrew/lib/libcrypto.3.dylib" "@loader_path/../Frameworks/libcrypto.dylib" "$VST3_BINARY" 2>/dev/null || true
                install_name_tool -change "/usr/local/lib/libssl.3.dylib" "@loader_path/../Frameworks/libssl.dylib" "$VST3_BINARY" 2>/dev/null || true
                install_name_tool -change "/usr/local/lib/libcrypto.3.dylib" "@loader_path/../Frameworks/libcrypto.dylib" "$VST3_BINARY" 2>/dev/null || true
            fi

            xattr -rd com.apple.quarantine "$VST3_TARGET" 2>/dev/null || true

            chmod -R 755 "$VST3_TARGET" 2>/dev/null || true

            if [ -d "$VST3_TARGET/AnalogMorphV333.vst3/Contents/MacOS" ]; then
                chmod +x "$VST3_TARGET/AnalogMorphV333.vst3/Contents/MacOS/"* 2>/dev/null || true
            fi
        else
            print_error "VST3 extraction failed!"
            INSTALL_SUCCESS=false
        fi
    fi
    echo ""
fi

if [ "$HAS_AU" = "true" ] && [ -f "$AU_ZIP" ]; then
    print_info "Installing AU..."

    if ! mkdir -p "$AU_TARGET" 2>/dev/null; then
        print_error "Failed to create directory: $AU_TARGET"
        INSTALL_SUCCESS=false
    else
        if unzip -o -q "$AU_ZIP" -d "$AU_TARGET" 2>/dev/null; then
            print_success "AU extracted to: $AU_TARGET"

            # CRITICAL: Fix dylib path references for DAW compatibility
            # Patches absolute paths to use @loader_path for bundled dependencies
            AU_BINARY="$AU_TARGET/AnalogMorphV333.component/Contents/MacOS/AnalogMorphV333"
            if [ -f "$AU_BINARY" ]; then
                install_name_tool -change "/tmp/openssl-universal/lib/libssl.3.dylib" "@loader_path/../Frameworks/libssl.dylib" "$AU_BINARY" 2>/dev/null || true
                install_name_tool -change "/tmp/openssl-universal/lib/libcrypto.3.dylib" "@loader_path/../Frameworks/libcrypto.dylib" "$AU_BINARY" 2>/dev/null || true
                install_name_tool -change "/opt/homebrew/lib/libssl.3.dylib" "@loader_path/../Frameworks/libssl.dylib" "$AU_BINARY" 2>/dev/null || true
                install_name_tool -change "/opt/homebrew/lib/libcrypto.3.dylib" "@loader_path/../Frameworks/libcrypto.dylib" "$AU_BINARY" 2>/dev/null || true
                install_name_tool -change "/usr/local/lib/libssl.3.dylib" "@loader_path/../Frameworks/libssl.dylib" "$AU_BINARY" 2>/dev/null || true
                install_name_tool -change "/usr/local/lib/libcrypto.3.dylib" "@loader_path/../Frameworks/libcrypto.dylib" "$AU_BINARY" 2>/dev/null || true
            fi

            xattr -rd com.apple.quarantine "$AU_TARGET" 2>/dev/null || true

            chmod -R 755 "$AU_TARGET" 2>/dev/null || true

            if [ -d "$AU_TARGET/AnalogMorphV333.component/Contents/MacOS" ]; then
                chmod +x "$AU_TARGET/AnalogMorphV333.component/Contents/MacOS/"* 2>/dev/null || true
            fi
        else
            print_error "AU extraction failed!"
            INSTALL_SUCCESS=false
        fi
    fi
    echo ""
fi

if [ "$HAS_PRESETS" = "true" ] && [ -f "$PRESETS_ZIP" ]; then
    print_info "Installing factory presets..."

    if ! mkdir -p "$PRESET_TARGET" 2>/dev/null; then
        print_error "Failed to create preset directory: $PRESET_TARGET"
        INSTALL_SUCCESS=false
    else
        if unzip -o -q "$PRESETS_ZIP" -d "$TEMP_DIR" 2>/dev/null; then
            cp -R "$TEMP_DIR"/* "$PRESET_TARGET/" 2>/dev/null || true

            xattr -rd com.apple.quarantine "$PRESET_TARGET" 2>/dev/null || true

            chmod -R u+rw,go+r "$PRESET_TARGET" 2>/dev/null || true

            PRESET_COUNT=$(find "$PRESET_TARGET" -name "*.analogmorph" 2>/dev/null | wc -l | xargs)
            print_success "Installed $PRESET_COUNT factory presets"
        else
            print_error "Presets extraction failed!"
            INSTALL_SUCCESS=false
        fi
    fi
    echo ""
fi

print_header
if [ "$INSTALL_SUCCESS" = true ]; then
    print_success "✅ Installation Complete!"
    echo ""
    print_info "Installed:"
    if [ "$HAS_VST3" = "true" ]; then
        echo "  📦 $VST3_TARGET/AnalogMorphV333.vst3"
    fi
    if [ "$HAS_AU" = "true" ]; then
        echo "  📦 $AU_TARGET/AnalogMorphV333.component"
    fi
    if [ "$HAS_PRESETS" = "true" ]; then
        echo "  📦 $PRESET_TARGET/ ($PRESET_COUNT presets)"
    fi
    echo ""
    print_info "Next steps:"
    echo "  1. Restart your DAW"
    echo "  2. Rescan plugins"
    echo "  3. Look for 'AnalogMorphV333' in your plugin list"
else
    print_error "Installation completed with errors"
    print_info "Some plugins may not have been installed correctly."
fi
print_header
echo ""

echo "Press any key to close..."
read -n 1
