#!/bin/bash
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# AnalogMorphV333 Installer Launcher
# Double-click this file to start installation
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

# Remove quarantine from all files in this folder
xattr -rd com.apple.quarantine "$SCRIPT_DIR" 2>/dev/null || true

# Check if .app exists (use full path)
APP_PATH=$(find "$SCRIPT_DIR" -maxdepth 1 -name "*.app" -type d | head -1)

if [ -n "$APP_PATH" ] && [ -d "$APP_PATH" ]; then
    # Launch the .app using full path (open command requires full path)
    open "$APP_PATH"
else
    # Fallback to Install.command if .app not found
    if [ -f "$SCRIPT_DIR/Install.command" ]; then
        chmod +x "$SCRIPT_DIR/Install.command"
        "$SCRIPT_DIR/Install.command"
    else
        echo "Error: No installer found"
        read -p "Press Enter to close..."
    fi
fi
