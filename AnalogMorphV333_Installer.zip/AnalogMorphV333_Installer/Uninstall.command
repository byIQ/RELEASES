#!/bin/bash

# AnalogMorphV333 Uninstaller Script
# Plugin: AnalogMorphV333 v1.0.0
# This script safely removes the plugin from your system

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Logging functions
log_info() {
    echo -e "${BLUE}ℹ${NC} $1"
}

log_success() {
    echo -e "${GREEN}✓${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}⚠${NC} $1"
}

log_error() {
    echo -e "${RED}✗${NC} $1"
}

# Get home directory
HOME_DIR="$HOME"

# Plugin information
PLUGIN_NAME="AnalogMorphV333"
PLUGIN_VERSION="1.0.0"
PRESET_FOLDER_NAME="AnalogMorphV333"
HAS_VST3="true"
HAS_AU="true"

# VST3 plugin location
VST3_PATH="$HOME_DIR/Library/Audio/Plug-Ins/VST3"
VST3_PLUGIN="$VST3_PATH/${PLUGIN_NAME}.vst3"

# AU plugin location
AU_PATH="$HOME_DIR/Library/Audio/Plug-Ins/Components"
AU_PLUGIN="$AU_PATH/${PLUGIN_NAME}.component"

# Preset locations
PRESET_LOCATIONS=(
    "$HOME_DIR/Library/Application Support/AnalogMorph"
    "$HOME_DIR/Library/Application Support/$PLUGIN_NAME"
    "$HOME_DIR/Documents/$PLUGIN_NAME Presets"
)

# Function to remove plugin bundle
remove_plugin() {
    local plugin_path="$1"
    local plugin_type="$2"
    
    if [ -e "$plugin_path" ]; then
        echo ""
        log_info "Found $plugin_type at: $plugin_path"
        
        # Ask for confirmation
        read -p "Remove $plugin_type? (yes/no): " -n 3 -r confirm
        echo ""
        
        if [[ $confirm == "yes" ]]; then
            if rm -rf "$plugin_path"; then
                log_success "Removed $plugin_type"
                return 0
            else
                log_error "Failed to remove $plugin_type (may require admin privileges)"
                return 1
            fi
        else
            log_warning "Skipped removing $plugin_type"
            return 0
        fi
    else
        log_warning "Plugin not found at: $plugin_path"
        return 0
    fi
}

# Function to remove presets
remove_presets() {
    local found_any=0
    
    for preset_location in "${PRESET_LOCATIONS[@]}"; do
        if [ -d "$preset_location" ]; then
            if [ -n "$(ls -A "$preset_location" 2>/dev/null)" ]; then
                found_any=1
                echo ""
                log_info "Found presets at: $preset_location"
                
                read -p "Remove presets at this location? (yes/no): " -n 3 -r confirm
                echo ""
                
                if [[ $confirm == "yes" ]]; then
                    if rm -rf "$preset_location"; then
                        log_success "Removed presets from: $preset_location"
                    else
                        log_error "Failed to remove presets (may require admin privileges)"
                    fi
                else
                    log_warning "Skipped removing presets from: $preset_location"
                fi
            fi
        fi
    done
    
    if [ $found_any -eq 0 ]; then
        log_warning "No preset folders found"
    fi
}

# Function to clear DAW plugin caches
clear_daw_caches() {
    log_info "Clearing DAW plugin caches..."
    
    # Logic Pro cache
    if [ -d "$HOME_DIR/Library/Caches/com.apple.Logic.Pro" ]; then
        log_info "Clearing Logic Pro cache..."
        rm -rf "$HOME_DIR/Library/Caches/com.apple.Logic.Pro"
        log_success "Cleared Logic Pro cache"
    fi
    
    # Ableton Live cache
    if [ -d "$HOME_DIR/Library/Preferences/Ableton/Live" ]; then
        log_warning "Found Ableton Live - you may want to manually clear plugin cache"
    fi
    
    # GarageBand
    if [ -d "$HOME_DIR/Library/Caches/GarageBand" ]; then
        rm -rf "$HOME_DIR/Library/Caches/GarageBand" 2>/dev/null || true
        log_success "Cleared GarageBand cache"
    fi
}

# Main uninstall process
main() {
    clear
    echo "╔════════════════════════════════════════════════╗"
    echo "║     ${PLUGIN_NAME} Uninstaller               ║"
    echo "║                 Version ${PLUGIN_VERSION}                ║"
    echo "╚════════════════════════════════════════════════╝"
    echo ""
    
    # Close any running DAWs (optional but recommended)
    log_warning "Please close all DAWs before continuing"
    echo ""
    read -p "Press ENTER to continue or Ctrl+C to cancel..."
    echo ""
    
    # Check what's installed
    local has_vst3_installed=0
    local has_au_installed=0
    
    if [ "$HAS_VST3" = "true" ] && [ -e "$VST3_PLUGIN" ]; then
        has_vst3_installed=1
    fi
    
    if [ "$HAS_AU" = "true" ] && [ -e "$AU_PLUGIN" ]; then
        has_au_installed=1
    fi
    
    if [ $has_vst3_installed -eq 0 ] && [ $has_au_installed -eq 0 ]; then
        log_warning "Plugin does not appear to be installed"
        echo ""
        read -p "Do you want to continue uninstall anyway? (yes/no): " -n 3 -r confirm
        echo ""
        if [[ ! $confirm == "yes" ]]; then
            log_info "Uninstall cancelled"
            exit 0
        fi
    fi
    
    # Remove VST3
    if [ "$HAS_VST3" = "true" ]; then
        remove_plugin "$VST3_PLUGIN" "VST3 Plugin"
    fi
    
    # Remove AU
    if [ "$HAS_AU" = "true" ]; then
        remove_plugin "$AU_PLUGIN" "AU Plugin"
    fi
    
    # Ask about presets
    echo ""
    read -p "Do you want to remove presets as well? (yes/no): " -n 3 -r confirm
    echo ""
    if [[ $confirm == "yes" ]]; then
        remove_presets
    else
        log_info "Presets will be preserved"
    fi
    
    # Clear DAW caches
    echo ""
    log_info "Clearing DAW plugin caches..."
    clear_daw_caches
    
    # Summary
    echo ""
    echo "╔════════════════════════════════════════════════╗"
    log_success "Uninstall completed successfully!"
    echo "╚════════════════════════════════════════════════╝"
    echo ""
    log_info "Next steps:"
    echo "  1. Restart your DAW"
    echo "  2. Rescan plugins if the DAW prompts"
    echo "  3. Plugin will no longer appear in plugin lists"
    echo ""
    
    read -p "Press ENTER to close this window..."
}

# Run main function
main "$@"
